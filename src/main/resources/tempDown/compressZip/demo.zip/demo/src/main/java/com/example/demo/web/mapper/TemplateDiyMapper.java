package com.example.demo.web.mapper;
import com.example.demo.web.domain.*;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author ：JiaGuo
 * @date ：Created in 2021/12/2 17:20
 * @description：这是TemplateDiy的持久层
 * @modified By：
 * @version: 1.0
 */
@Mapper
public interface TemplateDiyMapper extends BaseMapper<TemplateDiyDomain> {
}
