package com.example.demo.web.domain;
import com.baomidou.mybatisplus.annotation.TableId;
/**
 * @author ：JiaGuo
 * @date ：Created in 2021/12/2 17:20
 * @description：这是TemplateManage的实体类
 * @modified By：
 * @version: 1.0
 */
@Data
@TableName("\" template_manage\"")
public class TemplateManageDomain {
     private String  templateType;
     private String  templateName;
     private String  createTime;
     private Boolean  delMark;
     private String  templateContent;
     private String  packageName;
     private int  templateId;
     private String  autor;
}
