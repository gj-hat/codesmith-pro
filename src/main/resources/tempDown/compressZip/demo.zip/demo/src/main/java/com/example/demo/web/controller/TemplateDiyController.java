package com.example.demo.controller;
import com.example.demo.web.domain.TemplateDiy;
import com.example.demo.web.service.TemplateDiyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
/**
 * @author ：JiaGuo
 * @date ：Created in 2021/11/17 17:45
 * @description： 表现层
 * @modified By：
 * @version: 1.0
 */
@RestController
@RequestMapping("/templateDiy")
public class TemplateDiyController {
    @Autowired
    private TemplateDiyService templateDiyService;

    @RequestMapping("/list")
    public List<TemplateDiy> list() {
        return templateDiy.list();
    }
    @RequestMapping("/save")
    public void save(@RequestBody TemplateDiy templateDiy) {
            templateDiyService.save();
    }
    @RequestMapping("/update")
    public void update(@RequestBody TemplateDiy templateDiy) {
            templateDiyService.update(templateDiy);
    }
    @RequestMapping("/del")
    public void del(@RequestBody int[] ids) {
            templateDiyService.del(ids);
    }
}
