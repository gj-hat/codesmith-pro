package com.example.demo.web.service;
import com.example.demo.web.domain.*;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author ：JiaGuo
 * @date ：Created in 2021/12/2 17:20
 * @description：这是Dependencies的业务层接口
 * @modified By：
 * @version: 1.0
 */
public interface DependenciesService extends IService<DependenciesDomain> {
}
