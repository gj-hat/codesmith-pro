package com.example.demo.web.service.Impl;
import com.example.demo.web.domain.TemplateDiyDomain;
import com.example.demo.web.mapper.TemplateDiyMapper;
import com.example.demo.web.service.TemplateDiyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * @author ：JiaGuo
 * @date ：Created in 2021/12/2 17:20
 * @description：这是TemplateDiy的业务层实现
 * @modified By：
 * @version: 1.0
 */
@Service
public class TemplateDiyServiceImpl extends ServiceImpl<TemplateDiyMapper, TemplateDiyDomain> implements TemplateDiyService {
}
