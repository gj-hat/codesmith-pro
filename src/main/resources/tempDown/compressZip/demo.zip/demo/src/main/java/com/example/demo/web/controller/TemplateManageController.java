package com.example.demo.controller;
import com.example.demo.web.domain.TemplateManage;
import com.example.demo.web.service.TemplateManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
/**
 * @author ：JiaGuo
 * @date ：Created in 2021/11/17 17:45
 * @description： 表现层
 * @modified By：
 * @version: 1.0
 */
@RestController
@RequestMapping("/templateManage")
public class TemplateManageController {
    @Autowired
    private TemplateManageService templateManageService;

    @RequestMapping("/list")
    public List<TemplateManage> list() {
        return templateManage.list();
    }
    @RequestMapping("/save")
    public void save(@RequestBody TemplateManage templateManage) {
            templateManageService.save();
    }
    @RequestMapping("/update")
    public void update(@RequestBody TemplateManage templateManage) {
            templateManageService.update(templateManage);
    }
    @RequestMapping("/del")
    public void del(@RequestBody int[] ids) {
            templateManageService.del(ids);
    }
}
