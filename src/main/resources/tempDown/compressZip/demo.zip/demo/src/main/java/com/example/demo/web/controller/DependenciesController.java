package com.example.demo.controller;
import com.example.demo.web.domain.Dependencies;
import com.example.demo.web.service.DependenciesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
/**
 * @author ：JiaGuo
 * @date ：Created in 2021/11/17 17:45
 * @description： 表现层
 * @modified By：
 * @version: 1.0
 */
@RestController
@RequestMapping("/dependencies")
public class DependenciesController {
    @Autowired
    private DependenciesService dependenciesService;

    @RequestMapping("/list")
    public List<Dependencies> list() {
        return dependencies.list();
    }
    @RequestMapping("/save")
    public void save(@RequestBody Dependencies dependencies) {
            dependenciesService.save();
    }
    @RequestMapping("/update")
    public void update(@RequestBody Dependencies dependencies) {
            dependenciesService.update(dependencies);
    }
    @RequestMapping("/del")
    public void del(@RequestBody int[] ids) {
            dependenciesService.del(ids);
    }
}
