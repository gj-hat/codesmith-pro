package com.example.demo.web.domain;
import com.baomidou.mybatisplus.annotation.TableId;
/**
 * @author ：JiaGuo
 * @date ：Created in 2021/12/2 17:20
 * @description：这是Dependencies的实体类
 * @modified By：
 * @version: 1.0
 */
@Data
@TableName("\" dependencies\"")
public class DependenciesDomain {
     private String  reference;
     private String  versionRange;
     private String  groupName;
     private String  sourceType;
     private String  name;
     private String  description;
     private String  id;
}
