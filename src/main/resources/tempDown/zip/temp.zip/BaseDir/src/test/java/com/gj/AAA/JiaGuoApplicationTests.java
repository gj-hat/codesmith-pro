package com.gj.AAA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiaGuoApplicationTests {

	@Test
	void contextLoads() {
	}

}
